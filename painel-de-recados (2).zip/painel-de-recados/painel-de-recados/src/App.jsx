import { useState } from "react";
import "./App.css";

export default function App() {
  const [texto, setTexto] = useState("");
  const [recados, setRecados] = useState([
    { id: 1, texto: "Entregar atividade até sexta", importante: false },
    { id: 2, texto: "Trazer notebook na próxima aula", importante: true },
  ]);

  function adicionar() {
    const valor = texto.trim();
    if (!valor) return;
    setRecados([...recados, { id: Date.now(), texto: valor, importante: false }]);
    setTexto("");
  }

  function remover(id) {
    setRecados(recados.filter((r) => r.id !== id));
  }

  function alternarImportante(id) {
    setRecados(
      recados.map((r) => (r.id === id ? { ...r, importante: !r.importante } : r))
    );
  }

  return (
    <main className="painel">
      <h1>Painel de Recados</h1>
      <p className="subtitulo">Organize comunicados da turma com clareza ✨</p>

      <div className="entrada">
        <input
          type="text"
          placeholder="Digite um recado"
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && adicionar()}
        />
        <button className="btn adicionar" onClick={adicionar}>
          Adicionar
        </button>
      </div>

      {recados.length === 0 ? (
        <p className="vazio">Nenhum recado por aqui. Adicione o primeiro!</p>
      ) : (
        recados.map((r) => (
          <div key={r.id} className={`recado ${r.importante ? "importante" : ""}`}>
            <p>{r.texto}</p>
            <div className="acoes">
              <button className="btn marcar" onClick={() => alternarImportante(r.id)}>
                {r.importante ? "Desmarcar" : "Importante"}
              </button>
              <button className="btn remover" onClick={() => remover(r.id)}>
                Remover
              </button>
            </div>
          </div>
        ))
      )}
    </main>
  );
}
